
<?php
$host = 'ucka.veleri.hr';
$db   = 'bkovacevic'; 
$user = 'bkovacevic'; 
$pass = '11'; 

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Povezivanje sa bazom nije uspelo: " . $e->getMessage());
}
?>
