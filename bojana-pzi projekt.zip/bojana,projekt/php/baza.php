<?php
// Podaci za povezivanje
$host = "localhost"; // Lokacija servera baze
$username = "root"; // Korisničko ime za bazu
$password = ""; // Lozinka (ako nema, ostavi prazno)
$dbname = "AutomobiliDB"; // Ime baze podataka

// Povezivanje s bazom
$conn = new mysqli($host, $username, $password, $dbname);

// Provjera povezanosti
if ($conn->connect_error) {
    die("Povezivanje s bazom nije uspjelo: " . $conn->connect_error);
}
?>
