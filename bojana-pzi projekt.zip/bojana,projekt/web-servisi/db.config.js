module.exports = {
    HOST: "",
    USER: "",
    PASSWORD: "",
    DB: ""
    };